---
name: freshrss-integration
description: Connect to FreshRSS via Google Reader API — authenticate, fetch unread articles, get content, mark read.
category: devops
---

## FreshRSS API Integration

FreshRSS exposes a Google Reader-compatible API at `/api/greader.php`. Use it to programmatically manage RSS feeds and articles.

### Authentication

FreshRSS uses Google Reader-style ClientLogin:

```bash
curl -s -X POST "https://<freshrss-url>/api/greader.php/accounts/ClientLogin" \
  -d "Email=<username>&Passwd=<api-password>&service=reader"
```

Response format:
```
SID=<username>/<token>
LSID=null
Auth=<username>/<token>
```

The `Auth` token lasts ~2 hours. Cache it and reuse until expired.

### Python Integration Pattern

```python
import requests

FRESHRSS_URL = "https://freshrss.example.com"
USERNAME = "josh434"
API_PASSWORD = "your-api-password"
API = f"{FRESHRSS_URL}/api/greader.php"

_auth_token = None

def get_auth_token():
    global _auth_token
    if _auth_token:
        return _auth_token
    resp = requests.post(
        f"{API}/accounts/ClientLogin",
        data={"Email": USERNAME, "Passwd": API_PASSWORD, "service": "reader"},
        timeout=30,
    )
    for line in resp.text.splitlines():
        if line.startswith("Auth="):
            _auth_token = line[5:]
            return _auth_token
    raise ValueError(f"Auth failed: {resp.text[:200]}")

def api_get(path, params=None):
    token = get_auth_token()
    return requests.get(
        f"{API}{path}",
        params=params,
        headers={"Authorization": f"GoogleLogin auth={token}"},
        timeout=60,
    )
```

### Fetching Unread Articles

```python
# Fetch unread items from reading list
resp = api_get(
    "/reader/api/0/stream/contents/user/-/state/com.google/reading-list",
    params={"n": 100, "output": "json", "r": "a"},  # "r": "a" = unread only
)
data = resp.json()
for item in data.get("items", []):
    title = item.get("title", "?")
    alts = item.get("alternate", [])
    url = alts[0]["href"] if alts else ""
    content = item.get("content", {}).get("content", "")
    summary = item.get("summary", {}).get("content", "")
```

**Important:** FreshRSS often stores truncated content (feeds with `<content>` may be empty). Always check `content` first, fall back to `summary`, and if both are short, fetch the original URL. **Also clean HTML tags and entities from extracted content** — use regex pattern `&(?:[a-zA-Z]+|#\d+|#x[0-9a-fA-F]+);` to handle named (`&copy;`), numeric (`&#169;`), and hex (`&#xA9;`) HTML entities, then strip tags with `<[^<]+?>`.

### Marking Articles as Read

```python
resp = api_get(
    "/reader/api/0/edit-tag",
    params={
        "i": "article-id-here",  # the id field from the item
        "a": "user/-/state/com.google/read",
        "r": "n",  # remove from reading list
    },
)
```

### Key API Endpoints

| Endpoint | Purpose |
|----------|---------|
| `/accounts/ClientLogin` | Authenticate |
| `/reader/api/0/user-info` | Get user info |
| `/reader/api/0/subscription/list` | List all subscriptions |
| `/reader/api/0/stream/contents/<stream-id>` | Get items from a stream |
| `/reader/api/0/unread-count` | Get unread counts per feed |
| `/reader/api/0/edit-tag` | Mark articles read/starred |
| `/reader/api/0/tag/list` | List all tags/labels |

### Stream IDs

| Stream | ID |
|--------|-----|
| Reading list (all) | `user/-/state/com.google/reading-list` |
| All starred | `user/-/state/com.google/starred` |
| Tag/label | `user/-/label/<tag-name>` |

### Common Pitfalls

1. **Content is ALWAYS truncated** — In practice, FreshRSS returns empty `content` fields (0 chars) for 100% of articles across all feeds. The `summary` field is populated but often too short for summarization. Plan for a content waterfall on every single article: check `content` → check `summary` → use `web_extract` on the original URL as the reliable fallback. Do NOT rely on FreshRSS content fields for newsletter-quality text.

2. **Pagination** — API returns continuation tokens. Use `c=<continuation>` param for subsequent pages.

3. **Token expiry** — Auth tokens last ~2 hours. Implement re-authentication on 401/403 responses.

4. **Username required** — Even if the app uses only an "API password", the ClientLogin endpoint requires `Email=<username>`. The username is the FreshRSS login username (e.g., `josh434`).

5. **Published timestamps** — `item.get("published", 0)` may be a string or integer. Always handle both types.

6. **Scale considerations** — Users with many subscriptions (400+) may have 16,000+ accumulated unread articles. Always filter by a lookback window (e.g., 24 hours) and set MAX_ARTICLES limits.

7. **Virtual Hosting Requirement** — When FreshRSS is accessed via IP address (rather than hostname), it may require a specific `Host` header to route correctly. If you get 404 errors on API endpoints despite the service running, try adding the Host header matching your FreshRSS domain (e.g., `Host: freshrss.example.com`). This is common in Docker/reverse proxy setups.

8. **Endpoint Availability** — Some API endpoints like `/reader/api/0/subscription/list` and `/reader/api/0/unread-count` may return 501 Not Implemented depending on server configuration/plugins. Core endpoints (`/accounts/ClientLogin`, `/reader/api/0/user-info`, `/reader/api/0/stream/contents/*`, `/reader/api/0/edit-tag`) are typically always available.

9. **Reasoning-only default model breaks summarization.** The user's OpenRouter default (`tencent/hy3:free`) returns `message.content is None` and hides the answer in `message.reasoning`. Summarizers that do `content.strip()` crash into messy fallback text (raw `TITLE:`/`CONTENT:` blobs, uncleaned HTML entities, leaked Chinese refusals). Fix: call with `extra_body={"reasoning": {"effort": "minimal"}}` AND `max_tokens` ≥ 2500 (retry 4000). No other free model is available on this key. See `references/reasoning-model-summarization.md`.

### Real-World Usage Notes

- **All feeds tested were truncated** (0 words in content field across 15+ articles from different sources). The content waterfall is not optional — it's the primary extraction path.
- **Typical setup**: 432 subscriptions, ~16,489 unread articles accumulated. Use `LOOKBACK_HOURS=24` and `MAX_ARTICLES=25` for daily newsletters.

### Production Usage Patterns

Based on real-world usage in the newsletter builder script:

1. **Timeout Handling**: External services like Jina Reader and OpenRouter may timeout or rate-limit. Implement fallback strategies:
   - Jina Reader failures should fall back to `web_extract` (which handles most major news sites well) or direct fetch + trafilatura
   - OpenRouter/API failures should fall back to content truncation
   - Always have a ultimate fallback (e.g., "[Unable to extract content]")

2. **Jina Reader Rate Limiting (402)**: Jina's `r.jina.ai` endpoint frequently returns HTTP 402 (Payment Required) when called in batch or without a valid API key. Do NOT rely on Jina as the primary extraction method. Use `web_extract` as the primary fallback for truncated FreshRSS content — it reliably fetches full article text from most news sites. Reserve Jina for sites that `web_extract` cannot handle.

2. **IP-Direct with Host Header**: When accessing via IP (common in Docker/reverse proxy setups):
   ```python
   ip_base = f"https://{FRESHRSS_IP}:{FRESHRSS_PORT}/api"
   headers = {
       'Host': FRESHRSS_HOST,  # Critical for virtual hosting
       'Authorization': f'GoogleLogin auth={auth_token}',
       'User-Agent': 'Mozilla/5.0 (compatible; Hermes-Newsletter/1.0)'
   }
   resp = requests.get(f"{ip_base}/greader.php{path}", params=params, headers=headers, timeout=60, verify=False)
   ```

3. **Client-Side Filtering**: For reliable results, fetch a generous batch and filter client-side:
   - Filter by timestamp using `timestampUsec` or `crawlTimeMsec` (more reliable than `published`)
   - Filter by read status via `'user/-/state/com.google/reading-list' in categories`
   - Apply topic/exclusion filters (e.g., exclude sports) based on title/content/categories
   - Sort by timestamp (newest first) and apply limits

4. **Error Handling**: Expect and handle:
   - Jina Reader timeouts (especially under load)
   - OpenRouter rate limits/key limits (403 errors)
   - Network timeouts to external services
   - Always provide meaningful fallbacks rather than failing completely
### Virtual Host Requirement & IP-Direct Access
When accessing FreshRSS via IP address (to avoid DNS/hosts file modifications), you must preserve the original Host header for virtual hosting to work correctly:

```python
# IP-direct connection pattern
ip_base = f"https://{FRESHRSS_IP}:{FRESHRSS_PORT}/api"
headers = {
    'Host': FRESHRSS_HOST,  # Original hostname for virtual hosting
    'Authorization': f'GoogleLogin auth={auth_token}',
    'User-Agent': 'Mozilla/5.0 (compatible; Hermes-Newsletter/1.0)'
}
resp = requests.get(f"{ip_base}/greader.php{path}", params=params, headers=headers, timeout=60, verify=False)
```

### Timestamp Handling Challenges
FreshRSS timestamp fields can be unreliable:
- The `published` field may contain future/past dates due to timezone issues
- More reliable timestamp fields are `timestampUsec` (microseconds) and `crawlTimeMsec` (milliseconds)
- Always validate timestamps before using them for filtering:
  ```python
  timestamp_usec = item.get('timestampUsec')
  if timestamp_usec:
      try:
          item_time = float(timestamp_usec) / 1000000  # Convert to seconds
      except (ValueError, TypeError):
          item_time = None
  ```

### Client-Side Filtering Approach
Instead of relying on API parameters `ot` (older than) and `r` (unread only) which can be tricky to use correctly, consider fetching a reasonable batch and filtering client-side:
1. Fetch items without time/read filters (or with generous limits)
2. Filter by time range using reliable timestamp fields (`timestampUsec` or `crawlTimeMsec`)
3. Filter by read status by checking for 'user/-/state/com.google/reading-list' in categories
4. Sort by timestamp (newest first) and apply your MAX_ARTICLES limit

Example filtering logic:
```python
cutoff_time = datetime.now() - timedelta(hours=LOOKBACK_HOURS)
cutoff_timestamp = cutoff_time.timestamp()

filtered_items = []
for item in items:
    # Check if unread
    categories = item.get('categories', [])
    is_unread = 'user/-/state/com.google/reading-list' in categories
    
    if not is_unread:
        continue
        
    # Check timestamp
    timestamp_usec = item.get('timestampUsec')
    crawl_time = item.get('crawlTimeMsec')
    item_time = None
    
    if timestamp_usec:
        try:
            item_time = float(timestamp_usec) / 1000000
        except (ValueError, TypeError):
            pass
    elif crawl_time:
        try:
            item_time = float(crawl_time) / 1000
        except (ValueError, TypeError):
            pass
    
    if item_time is None or item_time >= cutoff_timestamp:
        filtered_items.append(item)

# Sort by timestamp (newest first) and limit
def get_item_time(item):
    timestamp_usec = item.get('timestampUsec')
    crawl_time = item.get('crawlTimeMsec')
    published = item.get('published')
    
    if timestamp_usec:
        try:
            return float(timestamp_usec) / 1000000
        except (ValueError, TypeError):
            pass
    elif crawl_time:
        try:
            return float(crawl_time) / 1000
        except (ValueError, TypeError):
            pass
    elif published:
        try:
            return float(published)
        except (ValueError, TypeError):
            pass
    return 0

filtered_items.sort(key=get_item_time, reverse=True)
return filtered_items[:MAX_ARTICLES]
```

### OpenAI Dependency Fallback
The OpenAI library may have dependency issues (missing pydantic_core). Implement a fallback to simple truncation when summarization fails.

**CRITICAL PITFALL — reasoning-only default model (`tencent/hy3:free`).** The user's
configured OpenRouter default is a *reasoning* model. It returns `message.content is None`
and hides the answer in `message.reasoning` (which may even contain the model's refusal).
Calling `.content.strip()` on `None` crashes into the fallback with messy raw text (raw
`TITLE:`/`CONTENT:` blobs, uncleaned HTML entities, leaked Chinese refusals). Two things
are required for a clean summary:
  1. Pass `extra_body={"reasoning": {"effort": "minimal"}}`.
  2. Use a LARGE `max_tokens` budget (2500+, retry 4000). A 300-token budget is fully
     consumed by the reasoning trace before `content` is ever emitted.

Other free models are unavailable on this key (`gpt-4o-mini` → 403 key-limit; the
`:free` llama/gemini/phi models → 404). So `hy3:free` is the only path — make it work.

Robust summarizer (verified against the live model):
```python
def summarize_content(text, openrouter_key=None):
    if not text or len(text.strip()) < 50:
        return (text or "")[:300] + ("..." if len(text or "") > 300 else "")
    if not openrouter_key:
        return text[:300] + ("..." if len(text) > 300 else "")
    try:
        from openai import OpenAI
        # read model/base_url from _get_default_model() per your config
        client = OpenAI(api_key=openrouter_key, base_url="https://openrouter.ai/api/v1")
        messages = [
            {"role": "system", "content": "You are a news summarizer. Be direct and factual. No filler. Just state what happened and implications in 2-4 sentences."},
            {"role": "user", "content": f"Summarize these news items concisely.\n\n{text[:6000]}"},
        ]
        for budget in (2500, 4000):
            try:
                r = client.chat.completions.create(
                    model=model, messages=messages, max_tokens=budget, temperature=0.2,
                    extra_body={"reasoning": {"effort": "minimal"}})
                summary = r.choices[0].message.content
                if not summary or not summary.strip():
                    reasoning = getattr(r.choices[0].message, "reasoning", None)
                    if reasoning and reasoning.strip():
                        summary = reasoning.strip().split("\n")[-1]
                if summary and summary.strip():
                    return summary.strip()
            except Exception as e:
                print(f"    attempt(budget={budget}) failed: {e}")
        raise ValueError("Empty content after retries")
    except Exception as e:
        print(f"    Summarization failed: {e}")
        # Fallback to truncation (clean TITLE:/CONTENT: prefixes first)
        ...
```

Always clean extracted HTML before summarizing/printing — use `html.unescape` + tag strip
+ fullwidth→ASCII normalization (range U+FF01–U+FF5F, U+3000); never ship raw `&...;`
entities or `TITLE:`/`CONTENT:` scaffolding into the final newsletter. Drop bodies that
are refusals/boilerplate (Chinese `我无法提供`, Cloudflare `Just a moment`, `404 not found`,
`enable javascript`) — `extract_content_with_waterfall` should return `content=None` for
those so the caller skips them. See `references/reasoning-model-summarization.md`.

Jina Reader URL note: build it as `https://r.jina.ai/{url}` (full target URL appended).
The form `https://r.jina.ai/http://{url}` double-prefixes the protocol and is wrong.
- **Environment variables pattern**: Store FreshRSS credentials in `.env` as `FRESHRSS_API_PASSWORD=***` and `FRESHRSS_USERNAME=xxx`. Always set both variables at the same time (e.g., via Python file write). NEVER use `echo NEWVAR=value >> .env` to append — if the file lacks a trailing newline, the new line will concatenate onto the previous value. This is critical for passwords containing `$`, which bash will expand silently during echo append, corrupting the credential with no obvious error. Use `python3 -c \\\"...\\\"` or manual edit instead.

### Troubleshooting FreshRSS Access

Based on real-world testing, here are common issues and solutions:

**Symptom**: Connection timeouts, DNS resolution failures, or 404 errors

**Solutions**:
1. **Verify Host Header**: All requests MUST include `Host: freshrss.wineandgecko.com` when accessing via IP
   ```bash
   curl -vk -H \"Host: freshrss.wineandgecko.com\" https://10.1.1.10/api/greader.php
   ```

2. **Check /etc/hosts entry**: Add if missing
   ```
   10.1.1.10 freshrss.wineandgecko.com
   ```

3. **SSL Certificate**: Instance uses self-signed certificate (TRAEFIK DEFAULT CERT)
   - In code: Use `verify=False` or add cert to trusted store
   - In browsers: Proceed past security warning

4. **Newsletter Builder Issues**: If newsletter builder shows \"File unchanged since last read...\"
   - The script may be corrupted
   - Restore from backup or recreate
   - Ensure FRESHRSS_URL in newsletter_builder.py does NOT include /api/ (it's added later)

5. **Cron Job Failures**: Ensure cron jobs have the `freshrss-integration` skill attached
   - Use `cronjob update <job_id> skills='[\"freshrss-integration\"]'`

6. **Traefik Routing Verification**: If all requests (including root path `/`) return 404 when using IP direct with the correct `Host: freshrss.wineandgecko.com` header, Traefik is likely not routing the subdomain to the FreshRSS container. Troubleshoot:
   - Confirm FreshRSS container is running: `docker ps | grep freshrss`
   - Check Traefik configuration (Docker labels or dynamic config) for a Host rule matching `freshrss.wineandgecko.com` pointing to the FreshRSS service
   - Test Traefik's HTTP routing (bypass HTTPS): `curl -H "Host: freshrss.wineandgecko.com" http://<traefik-ip>:80/` (FreshRSS root should return a login page, not 404)
   - Test FreshRSS setup page: `curl -H "Host: freshrss.wineandgecko.com" http://<traefik-ip>:80/install.php` — if this returns 404, Traefik isn't routing any FreshRSS paths, including the setup page required for initialization
   - Quick diagnostic: If `curl -vk -H "Host: freshrss.wineandgecko.com" https://10.1.1.10/` returns 404, Traefik has no route for this host

### Newsletter Output Style

**User preference: direct, succinct, no grandiose language.** The newsletter must NOT use:
- Pretentious headers like "Weekly Intelligence Brief" or "Analyzed N developments across..."
- Flowery LLM summaries with phrases like "this means for the field and its broader implications"
- Section subtitles describing what each section covers (redundant with the header)

**Required style:**
- Header: `# News Brief` with a short timestamp — nothing more
- Section headers: short and simple (`🔬 Science`, `🤖 AI & Tech`, `🌍 World`)
- Summaries: state what happened, concrete implications, 2-4 sentences max
- System prompt for summarizer: "You are a news summarizer. Be direct and factual. No filler, no grandiose language, no 'this means for the field' commentary. Just state what happened and any concrete implications in 2-4 sentences max."
- Max tokens: 300, temperature: 0.2
- If no articles found: a single short line, no elaboration

When modifying or rebuilding the newsletter builder script (`~/.hermes/scripts/newsletter_builder.py`), always enforce these style constraints in the prompt template and output formatting.

### Newsletter Builder: Fetching & Categorization

The newsletter builder script (`~/.hermes/scripts/newsletter_builder.py`) uses FreshRSS to generate topic-based newsletters. Key patterns and pitfalls:

1. **ALWAYS use `"r": "n"` (newest first)** when fetching the reading list. Without this, the API returns oldest-first and your newsletter will show 82-day-old articles. This is the single most common bug.

2. **Finance exclusion before keyword scoring.** Earnings calls and fund commentaries often contain words like "research" (from "Research Division" in SeekingAlpha participant lists) or "ev" (from "Evercore"). Use a title regex pattern and finance keywords to detect these BEFORE scoring — then exclude them from all topic sections entirely.

   **Finance keyword patterns to exclude:**
   - Earnings patterns: `earnings call`, `earnings presentation`, `Q1 2026 earnings`, `Q4 2025 results`
   - Corporate press releases with tickers: `(TICKER) named|announces|validates|partners|launches|acquires`
   - Financial analysis terms: `beat estimates`, `consensus estimates`, `fiscal quarter`, `year-to-date`, `guidance`
   - Investment content: `cheap stocks`, `stocks to buy`, `about to explode`, `undervalued`, `price target`, `analyst rating`
   - Source identifiers: `market beat`, `seeking alpha`, `motley fool`, `insider monkey`, `zacks`, `benzinga`, `streetinsider`, `fool.com`

3. **Score-based categorization, not binary matching.** Use `sum(1 for kw in keywords if kw in combined)` with thresholds (>= 2 for AI/Science) instead of `any()` to avoid false positives from single ambiguous words.

4. **LLM hallucination risk.** When a section has too few articles (1-2), the LLM may hallucinate content to fill the space. Set minimum article counts per section or use bullet-point summaries.

5. **Summarization fallback cleanup.** When OpenRouter is rate-limited (403), the fallback truncation must clean the `TITLE:`/`CONTENT:` prefix format used during categorization. Extract text after the colon and join clean parts before truncating.

See `references/newsletter-builder-categorization.md` for detailed code patterns, regex patterns, and keyword lists.

### References
See `references/api-endpoints.md` for detailed endpoint testing results and working Python patterns specific to your FreshRSS instance at `https://freshrss.wineandgecko.com/api/`.
See `references/content-extraction-fallbacks.md` for the content extraction fallback hierarchy (web_extract > Jina > trafilatura) and Jina 402 rate-limiting notes.
See `references/freshrss-oracle-deployment.md` for steps to deploy FreshRSS on the Oracle server with Traefik.
See `references/traefik-routing-diagnostics.md` for step-by-step Traefik routing diagnostic commands to resolve 404 errors on FreshRSS API endpoints.
See `references/newsletter-builder-categorization.md` for newsletter builder fetching logic, categorization patterns, and content extraction pitfalls.
See `references/reasoning-model-summarization.md` for the verified fix recipe when the default OpenRouter model is reasoning-only (`tencent/hy3:free`) and silently returns `None` content.

7. **SearXNG at search.wineandgecko.com** — the HTML search endpoint works (200), but the JSON API (`/search?q=...&format=json`) returns 403. The SearXNG instance runs v2026.5.8 behind Traefik. The `search_format: json` output format is disabled in the SearXNG settings — to fix, either:
   - Edit the SearXNG `settings.yml` to enable `search_format: json` (or add `json` to the allowed output formats)
   - Or use an alternative free search backend: `ddgs` (DuckDuckGo, needs `pip install ddgs` + set `web.search_backend: ddgs` in config.yaml), or `brave-free` (needs `BRAVE_SEARCH_API_KEY`)

8. **Hardcoded IPs in Client Scripts**: The newsletter builder script (`~/.hermes/scripts/newsletter_builder.py`) has a hardcoded `freshrss_ip` value. The correct local server IP is `10.1.1.10` (not `161.153.112.27`, which was the old Oracle server IP). See `references/server-locations.md` for a full map of internal service IPs.

9. **Uninitialized FreshRSS Instance**: Newly deployed FreshRSS containers return "Not Found" on API endpoints until the initial web-based setup is completed. Access `http://freshrss.wineandgecko.com/install.php` to:
   - Create the admin user (username: `josh434`, password from `FRESHRSS_API_PASSWORD` in `~/.hermes/.env`)
   - Enable the Google Reader API in FreshRSS settings (Settings → Reading → Enable Google Reader API)
   - Note: CLI initialization attempts (e.g., `docker exec freshrss php /var/www/FreshRSS/app/install.php`) return "Forbidden" — only browser-based setup works.
   - Note: CLI initialization attempts (e.g., `docker exec freshrss php /var/www/FreshRSS/app/install.php`) return "Forbidden" — only browser-based setup is supported.

10. **Cron Job /etc/hosts Limitations**: Cron jobs (and non-sudo users) cannot modify `/etc/hosts`. If the FreshRSS hostname is not in `/etc/hosts`, DNS resolution will fail. The newsletter script uses IP direct with `Host` header to bypass this, but this only works if Traefik is correctly routing the subdomain. If Traefik routing is broken, even IP direct will fail with "Not Found" errors.

12. **FreshRSS Setup Page 404**: If `http://freshrss.wineandgecko.com/install.php` returns 404, Traefik is not routing the FreshRSS subdomain at all. The browser-based setup required for FreshRSS initialization cannot be completed until Traefik routing is fixed. This is a more severe issue than just API endpoint 404s.