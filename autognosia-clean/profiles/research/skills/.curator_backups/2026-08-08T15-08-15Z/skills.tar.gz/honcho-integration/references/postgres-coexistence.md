# PostgreSQL Coexistence — Honcho + TimescaleDB + LiteLLM

Verified working configuration (July 2025) where three PostgreSQL instances run simultaneously on separate Docker networks with no port conflicts.

## Container Inventory

| Container | Image | Host Port → Container Port | Docker Network | Purpose |
|-----------|-------|---------------------------|----------------|---------|
| `honcho_db` | `ankane/pgvector:latest` | **5433 → 5432** | `honcho_default` | Honcho memory (pgvector) |
| `default-postgres-1` | `timescale/timescaledb:latest-pg16` | 5432 → 5432 | `bridge` | General TimescaleDB |
| `litellm-postgres` | `postgres:15-alpine` | 5432 (internal only) | `lightllm_litellm-network` | LiteLLM proxy DB |

## Key Configurations

### Honcho (`~/honcho/docker-compose.yml`)
```yaml
services:
  database:
    image: ankane/pgvector:latest
    container_name: honcho_db
    environment:
      POSTGRES_USER: josh434
      POSTGRES_PASSWORD: J1234osh$
      POSTGRES_DB: honcho
    ports:
      - "5433:5432"  # Host 5433 → Container 5432
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U josh434 -d honcho"]
      interval: 5s
      timeout: 5s
      retries: 5
```

**Critical**: Healthcheck user (`josh434`) MUST match `POSTGRES_USER`. The default `honcho` would fail.

### TimescaleDB (default-postgres-1)
- Runs on default `bridge` network
- Standard PostgreSQL 16 with TimescaleDB extension
- Port 5432 exposed on host

### LiteLLM PostgreSQL (litellm-postgres)
- Runs on `lightllm_litellm-network` (isolated)
- Port 5432 only exposed internally to `litellm` container
- No host port mapping — avoids conflict entirely

## Network Isolation
```
honcho_default (172.18.0.0/16)     → honcho_db, honcho_server, honcho_deriver
bridge (172.17.0.0/16)             → default-postgres-1
lightllm_litellm-network (172.20.0.0/16) → litellm-postgres, litellm
```

Each network is completely isolated — containers on different networks cannot communicate directly, eliminating any possibility of cross-talk or connection confusion.

## Verification Commands

```bash
# Check all three are running
docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Ports}}" | grep -E "(honcho_db|default-postgres|litellm-postgres)"

# Verify Honcho API works
curl -s http://127.0.0.1:8000/v3/workspaces/list

# Verify TimescaleDB accessible
docker exec default-postgres-1 psql -U postgres -c "SELECT version();"

# Verify LiteLLM DB accessible
docker exec litellm-postgres psql -U litellm -d litellm -c "SELECT version();"
```

## When to Use This Pattern

Use this multi-network, multi-port approach when:
- Multiple services need PostgreSQL but have different schema/extension requirements
- You cannot consolidate databases (different teams, different lifecycles, different extensions)
- Port 5432 is already occupied and you need zero-downtime addition

Avoid when:
- Services can share a single PostgreSQL instance with separate databases/schemas
- Simpler deployment is preferred and isolation isn't required