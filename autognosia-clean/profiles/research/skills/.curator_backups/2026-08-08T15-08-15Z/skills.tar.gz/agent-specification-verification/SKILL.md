---
name: agent-specification-verification
category: software-development
description: Systematic approach to verify agent specification completeness before implementation, preventing partial implementations and ensuring all critical infrastructure agents are accounted for.
author: Hermes Agent System
version: 1.0.0
created: 2026-04-22
---

# Agent Specification Verification Skill

## Overview

When implementing agent-based systems from detailed specifications, **always verify the complete specification before starting implementation**. This skill provides a systematic approach to extract requirements, identify gaps, and create implementation plans.

## Problem This Solves

Common issues when building agent systems:
- ❌ Implementing agents without knowing the complete scope
- ❌ Missing critical infrastructure agents (A1-A5, B1-B3, etc.)
- ❌ Wasted effort on framework without core functionality
- ❌ Partial implementations that don't deliver business value
- ❌ No clear prioritization of what to build first
- ❌ Implementing agent logic that duplicates existing workflows/services
- ❌ Misunderstanding the agent vs workflow distinction (agents as decision layers, not workflow reimplementations)

## Skill: Agent Specification Verification

### Trigger Conditions

Use this skill when:
- Starting a new agent-based system implementation
- Switching models or losing specification context
- Building agents from detailed engineering specifications
- Implementing micro-agent architectures (24+ agents)
- Working with institutional-grade software requirements
- Need to verify completeness of specification vs. implementation

### Input Requirements

1. **Specification file path** - Location of detailed engineering specification
   - Example: `/home/josh434/.hermes/website_instructions`
   
2. **Implementation directory** - Where agents are/will be implemented
   - Example: `/home/josh434/wealthforge-ai/backend/app/api/v1/micro_agents/`
   
3. **Project context** - Additional project-specific information

### Step-by-Step Procedure

#### Step 1: Extract Complete Agent List from Specification

```python
# Use regex to extract all agent specifications
import re

with open(specification_path, 'r') as f:
    content = f.read()

# Find all agent definitions
agent_pattern = re.compile(r'^\s*(Agent [A-Z]\d+:|\d+\.\s+[A-Z][a-z]+.*Agent)', re.IGNORECASE)

all_agents = []
for line_num, line in enumerate(lines, 1):
    if agent_pattern.search(line):
        all_agents.append({'id': extract_agent_id(line), 'line': line_num, 'spec': line})
```

#### Step 2: Create Agent Registry Matrix

```python
# Build complete agent registry
agent_registry = {
    'total_specified': len(all_agents),
    'by_group': {},
    'by_llm_required': {'yes': 0, 'no': 0},
    'implemented': [],
    'missing': [],
    'partial': []
}

for agent in all_agents:
    group = agent['id'][0]  # A, B, C, etc.
    agent_registry['by_group'][group] = agent_registry['by_group'].get(group, 0) + 1
    
    # Check if implemented
    if is_implemented(agent['id']):
        agent_registry['implemented'].append(agent)
        agent_registry['by_llm_required']['yes' if agent_has_llm(agent['id']) else 'no'] += 1
    else:
        agent_registry['missing'].append(agent)
```

#### Step 3: Create Gap Analysis Report

```python
# Generate gap analysis
gap_report = {
    'total_specified': agent_registry['total_specified'],
    'total_implemented': len(agent_registry['implemented']),
    'total_missing': len(agent_registry['missing']),
    'completion_rate': (len(agent_registry['implemented']) / agent_registry['total_specified']) * 100,
    'critical_missing': [],
    'high_priority_missing': [],
    'medium_priority_missing': [],
    'low_priority_missing': []
}

# Categorize missing agents by priority
for agent in agent_registry['missing']:
    priority = determine_priority(agent['id'])
    gap_report[f'{priority}_priority_missing'].append(agent)
```

#### Step 4: Create Implementation Priority Matrix

```python
# Define priority categories
PRIORITY_RULES = {
    'blocker': ['A1', 'A2', 'A3', 'A4', 'A5', 'B1', 'B2', 'B3', 'C1', 'C2', 'F1', 'F2'],
    'high': ['D1', 'E2', 'H1', 'I1', 'I2', 'J2'],
    'medium': ['G1', 'G2', 'K1'],
    'low': []
}

def determine_priority(agent_id):
    for priority, agents in PRIORITY_RULES.items():
        if agent_id in agents:
            return priority
    return 'low'
```

#### Step 5: Generate Implementation Plan

```python
# Create week-by-week implementation schedule
WEEKLY_PLAN = {
    'week_1': {
        'title': 'Core Infrastructure Recovery',
        'agents': ['A1', 'A2', 'A3', 'A4', 'A5', 'B1', 'B2', 'B3'],
        'focus': 'Portfolio rebalancing and trade execution'
    },
    'week_2': {
        'title': 'Compliance & Payments',
        'agents': ['C1', 'C2', 'F1', 'F2'],
        'focus': 'Regulatory compliance and payment processing'
    },
    'week_3': {
        'title': 'Intelligence Systems',
        'agents': ['D1', 'E2', 'H1', 'J2'],
        'focus': 'Call/email intelligence and research tools'
    },
    'week_4': {
        'title': 'Analytics & Planning',
        'agents': ['G1', 'G2', 'I1', 'I2', 'K1'],
        'focus': 'Risk analytics and financial planning'
    }
}
```

#### Step 6: Create Quality Assessment Checklist

```python
# Quality expectations for each agent
QUALITY_CHECKLIST = {
    'base_requirements': [
        'BaseAgent inheritance',
        'Pydantic schemas with validation',
        'MCP integration and tool discovery',
        'Service injection (rebalancer, contact_manager, etc.)',
        'SEC/FINRA compliance hooks',
        'Determinism Ladder (80% rule-based, 20% LLM)',
        'Async patterns with error handling',
        'Agent event logging with supervision trail',
        'Human review gates where required',
        'Circuit breakers and rate limiting'
    ],
    'llm_agents': [
        'Strict JSON output constraints',
        'Context window management',
        'Tool call validation',
        'Error recovery strategies',
        'Performance optimization (XGrammar, constrained decoding)'
    ]
}
```

#### Step 7: Generate Assessment Documents

```python
# Create assessment output files
documents = {
    'ASSESSMENT_SUMMARY.md': generate_summary_markdown(gap_report, agent_registry),
    'AGENT_ASSESSMENT.md': generate_detailed_assessment(agent_registry),
    'IMPLEMENTATION_PLAN.md': generate_implementation_plan(WEEKLY_PLAN),
    'STATUS_UPDATE.txt': generate_quick_status(gap_report)
}

# Save all documents
for filename, content in documents.items():
    write_file(f'/path/to/project/{filename}', content)
```

### Outputs

This skill generates:

1. **ASSESSMENT_SUMMARY.md** - Executive summary with completion rates and critical gaps
2. **AGENT_ASSESSMENT.md** - Detailed breakdown of all agents with quality checks
3. **IMPLEMENTATION_PLAN.md** - Week-by-week implementation schedule
4. **STATUS_UPDATE.txt** - Quick visual summary for team communication
5. **Agent Registry Matrix** - Structured data for integration with other tools

### Pitfalls & Lessons Learned

**⚠️ Critical Pitfalls:**

1. **Framework-First Trap**
   - ❌ Build framework → then implement agents
   - ✅ **Verify specification → then build framework → then implement agents**
   - **Lesson:** Framework is useless without the core agents that deliver business value

2. **Partial Implementation Risk**
   - ❌ Implement "interesting" agents first (ClientOnboarding, MeetingPrep)
   - ✅ **Implement blocking agents first (A1-A5, B1-B3)**
   - **Lesson:** Core business logic must work before nice-to-have features

3. **Specification Context Loss**
   - ❌ Switch models → lose specification context → build wrong things
   - ✅ **Always re-verify specification after context changes**
   - **Lesson:** Specifications are living documents that need periodic review

4. **Quality vs. Completeness Trade-off**
   - ❌ Build 6 high-quality agents but miss 18 critical ones
   - ✅ **Complete coverage first, polish second**
   - **Lesson:** A working system with 25% coverage is better than a polished 25%

5. **Missing Verification Step**
   - ❌ Start coding immediately
   - ✅ **Verify specification completeness before writing first line**
   - **Lesson:** Always know what you're NOT building, not just what you ARE building

### Reusable Patterns

**Pattern 1: Specification Extraction**
- Use regex to extract structured requirements
- Build agent registry from specification
- Create gap analysis matrix

**Pattern 2: Priority-Based Implementation**
- Categorize by business impact (blocker, high, medium, low)
- Create week-by-week sprint plans
- Focus on revenue-generating features first

**Pattern 3: Quality Gates**
- Define minimum quality standards
- Checklist for each agent type
- Prevent partial/low-quality implementations

**Pattern 4: Documentation Generation**
- Automated markdown generation
- Structured data outputs
- Team communication artifacts

### Integration with Other Skills

This skill works well with:
- `systematic-debugging` - For troubleshooting partial implementations
- `test-driven-development` - To ensure new agents meet quality standards
- `wealthforge-subsystem-integration-pattern` - For institutional-grade integration
- `code-review` - To verify agent quality before merge

### Example Usage

```bash
# After creating the skill, use it like this:

# 1. Verify specification completeness
skill_view(name="agent-specification-verification")

# 2. Extract agent list and create gap analysis
# (The skill runs automatically when triggered by the conditions above)

# 3. Review generated documents
cat /home/josh434/wealthforge-ai/ASSESSMENT_SUMMARY.md
cat /home/josh434/wealthforge-ai/IMPLEMENTATION_PLAN.md
```

### When NOT to Use

Don't use this skill when:
- Implementing simple scripts (1-2 agents)
- Building prototypes without detailed specifications
- Working with vague requirements
- Implementing agents where the complete list isn't critical

### Maintenance

Update this skill when:
- New agent types are discovered
- Quality standards change
- New specification formats are used
- Integration patterns evolve

---

## Key Learning from This Session

**The Determinism Ladder Principle:**
> "Every piece of functionality is assigned to the lowest, most deterministic rung of this ladder before considering the next"

This applies not just to agent logic, but to **implementation strategy**:
1. **Verify specification** (deterministic: read docs)
2. **Create gap analysis** (deterministic: extract requirements)
3. **Build framework** (deterministic: create base classes)
4. **Implement agents** (80% rule-based: implement missing agents, 20% LLM: where language matters)

**Quality Standard:**
> "Build institutional-grade software with enterprise patterns"

This means:
- ✅ Complete coverage before polish
- ✅ Blockers first, nice-to-have second
- ✅ Automated testing for all new work
- ✅ Documentation as part of implementation

**The Hermes Principle:**
> "If you want to remember something, WRITE IT TO A FILE"

Applied here:
- Created ASSESSMENT_SUMMARY.md
- Created AGENT_ASSESSMENT.md  
- Created IMPLEMENTATION_PLAN.md
- Created STATUS_UPDATE.txt

Never rely on "mental notes" - document everything.
