---
name: uhnw-wealth-management
description: "Skills for modeling ultra-high-net-worth wealth management features: PPLI/PPVA integration, estate tax planning, multi-jurisdictional domicile optimization, family business valuation, and dynasty trust planning."
---

# UHNW Wealth Management Modeling

Skills for modeling ultra-high-net-worth (UHNW) wealth management features that go beyond standard retail financial planning.

## Scope

- **PPLI/PPVA**: Private placement life insurance wrapper modeling, subaccount correlation, collateral risk, offshore domiciles
- **Estate Planning**: Estate tax reversion, dynasty trusts, ILIT/SLAT integration
- **Cross-Border**: Multi-jurisdictional domicile optimization, trust law comparison
- **Business Integration**: Family business valuation, business exit planning

## PPLI Subaccount Correlation Modeling

For PPLI subaccount correlation modeling, see `references/ppli-correlation-modeling.md`. Covers:
- Glosten-Milne smoothing correction for lagged private asset valuations
- Regime-dependent correlation matrices (Normal/Stress/Deflation/Liquidity Crisis)
- Bounded smoothing correction to prevent impossible correlations
- Non-parametric correlation estimation (Spearman, Kendall, copula)
- Monte Carlo integration architecture for PPLI cash value projection

## Alternative Investment Correlation Reference

For correlation reference data across alternative asset classes, see `references/alt-investment-correlations.md`. Covers:
- Hedge fund strategy correlation clusters
- Private equity strategy correlations
- Private credit correlations
- Real asset correlations
- All data sourced from Cambridge Associates, Preqin, AIMA, SIFMA, NCREIF, MSCI

## Monte Carlo Integration for PPLI

When integrating PPLI into Monte Carlo simulation:
1. Generate correlated subaccount returns using regime-dependent matrices
2. Apply smoothing correction to NAV returns (bounded approach)
3. Project cash value with fee drag and COI charges
4. Track collateral ratio (CV/Loan) across all scenarios
5. Model lapse risk as discrete event at critical thresholds (CR < 0.50)

## PPLI Carrier Reference

| Carrier | Domicile | Focus |
|---|---|---|
| Providence Life | Bermuda | ~200+ fund options, broad access |
| Arca Insurance | Bermuda | SMA options for $10M+ |
| Geneva International | Bermuda/US | Two-company structure (US 953d + international) |
| BlackRock PPLI | Bermuda | Aladdin platform integration |
| Zurich Insurance Group | Bermuda | IDF (Insurance-Dedicated Funds) |
| Pacific Life | US | A.M. Best A++ |
| Crown Global | Bermuda | $10M+ premium focus |
| Clarion Capital | Bermuda | IDF platform |

## DAC Amortization Reference

For DAC carrier cost comparison, recovery speed rankings, and amortization methodology, see `ppli-dac-amortization.md` in the `wealthforge-domain-knowledge` skill. Covers:
- SFAS 97 k-factor amortization mechanics
- 11 domestic carrier DAC recovery rankings (7-14 year recovery periods)
- DAC tax surcharge by carrier (1.00-1.50% of premium)
- $1.2M-$1.6M cost spread on $50M portfolio between fastest/slowest carriers
- DAC impairment risk signals and interest rate sensitivity

## PPLI Carrier Health Monitoring

For SAC-level CSM floor proximity, acceleration factor calculations, carrier risk scoring, and data confidence methodology, see `references/ppli-carrier-monitoring.md`. Covers:
- Acceleration factor formula and asymmetric market shock impact (4x compression from -4% shock vs 0.25x expansion from +4% gain)
- AF classification thresholds (GREEN/YELLOW/ORANGE/RED)
- Exponential decay DTF calculation
- VFA vs General Model SAC classification
- Carrier risk score aggregation (CSM + DAC composite, 0-100 scale)
- Data confidence scoring framework
- Bermuda PPLI carrier data availability constraints

For assumption change direction reversal detection (DRC, NDS, RV, RAR, CRRS metrics), see `ppli-assumption-reversal-detection.md` in the `wealthforge-domain-knowledge` skill. Covers: 4-core metric system, composite scoring (0-100, 4-tier classification), data model, flagging logic, reversal pattern sub-types (oscillating/one-shot/gradual drift/market-chasing), 8 red-team edge cases, UI widgets, API design, and competitive landscape. Zero competitors detect assumption direction reversals.

## PPLI 1035 Exchange Optimization

For 1035 exchange analysis (breakeven, carrier comparison, underwriting, red-team edge cases), see `references/ppli-1035-exchange.md`. Covers:
- Breakeven formula: (Surrender_Charge + Setup_Cost) / Annual_Fee_Savings
- Tax alpha quantification: Gain × (Current_Rate - Future_Rate) × discount factor
- Six-carrier fee comparison (Providence, Arca, Geneva, Axis, RenRe, Pacific Life)
- Underwriting tiers ($1M-$10M+ with timeline/cost)
- Decision thresholds: <3yr breakeven = strong buy, >7yr = don't exchange
- 7 red-team edge cases (constructive receipt, lapse risk, Wyden legislative risk, etc.)
- Cost basis transfer mechanics (FIFO tracking into PPLI)

## Regulatory Framework

- **IRC 7702**: Minimum death benefit requirements for tax-deferred status
- **IRC 817(h)**: Adequate diversification (no single investment >25%, min 5 investments)
- **SEC Marketing Rule (2024)**: Net performance presentation requirements
- **FINRA 2111**: Suitability for PPLI recommendations
- **FATCA/FBAR**: Offshore PPLI reporting thresholds

## State Legislative Risk Monitoring

For state-by-state legislative risk tracking methodology, data sources, and compliance requirements, see `references/state-legislative-risk-overlay.md`. Covers:
- State Risk Score (SRS) formula: 4-component weighted model (conformity 30%, legislation 25%, revenue need 20%, political alignment 25%)
- Conformity classification: 4 categories (Full, Conditional, Non-Conforming, Active Decoupling)
- Federal + state combined risk calculation with super-additive correlation premium
- State-by-state quick reference matrix (as of May 2026): CA (83 CRITICAL), NY (65 HIGH), OR/ME/CT/IL (41-58 ORANGE), TX/FL/NV/WY (5 GREEN)
- Data sources: LegiScan API (primary), NASBO, NCSL, Cook PVI, ITEP estimates, paid services (State Net, PolicyNote, MultiState)
- Compliance: Reg BI material fact disclosure, FINRA 2111 audit trail, IRS unauthorized practice warnings
- Edge cases: retroactive legislation, multi-state domicile, state recapture provisions, business income sourcing
