# State-Level Legislative Risk Overlay (SLRO)

Framework for tracking state tax policy changes and their impact on UHNW deferral strategies (QSBS, QOF, PPLI).

## Core Framework

### State Risk Score (SRS) Formula

```
SRS = w1 * ConformityRisk + w2 * LegislationRisk + w3 * RevenueNeed + w4 * PoliticalRisk

w1 = 0.30 (conformity status is strongest predictor)
w2 = 0.25 (active legislation is most urgent signal)
w3 = 0.20 (revenue need is leading indicator)
w4 = 0.25 (political alignment determines passage probability)
```

### Conformity Classification

| Category | Description | QSBS Examples | SRS Range |
|----------|-------------|---------------|-----------|
| A: Full Conformity | Conforms to federal treatment | TX, FL, NV, SD, WY (no income tax) | 0-10 |
| B: Conditional | Conforms with limitations | NJ (under review), MA (3% tax), HI (50% cap) | 20-40 |
| C: Non-Conforming | Explicitly decoupled | CA (13.3%), AL, MS, PA (3.07%) | 50-70 |
| D: Active Decoupling | Legislation enacted/pending | OR (enacted Mar 2026), ME (passed), NY (proposed, retroactive) | 70-100 |

### SRS Interpretation

- **0-20 (Green):** Low risk. Conforming, no active legislation, favorable politics.
- **21-40 (Amber):** Moderate risk. Conditional conformity or pending legislation.
- **41-60 (Orange):** Elevated risk. Non-conforming or active decoupling. Client action may be needed.
- **61-80 (Red):** High risk. Enacted or actively pursuing decoupling. Immediate review required.
- **81-100 (Critical):** Critical risk. Retroactive decoupling or revenue crisis. Emergency action.

### Federal + State Combined Risk

```
CombinedRisk = 0.65 * FederalLRS + 0.35 * StateSRS

When both > 50: add correlation premium = (federal-50) * (state-50) / 100
  (super-additive due to coordinated revenue-raising packages)
```

**Critical finding:** For CA resident deploying QSBS stacking:
- Federal LRS = 30.8 (moderate)
- State SRS (CA, QSBS) = 85 (critical)
- CombinedRisk = 0.65 * 30.8 + 0.35 * 85 = **49.77** (elevated)
- QSBS drops from #1 to #3 in strategy ranking for CA residents

## Data Sources

### Primary Monitoring (Automated)
- **LegiScan API** — Free/low-cost, covers 50 states + DC, bill data, sponsor tracking
- **State legislature web portals** — Direct bill feeds
- **NASBO** — State budget survey, fiscal stress indicators

### Secondary Monitoring (Manual/Quarterly)
- **State tax authority publications** — Bulletins, notices, guidance
- **NCSL** — State government structure, partisan control
- **Cook Political Report** — State-level partisan voting indices
- **Credit rating agencies** — S&P, Moody's, Fitch state rating reports
- **ITEP** — State revenue loss estimates from federal decoupling

### Professional Services (Paid, $5K-$50K/year)
- **State Net (LexisNexis)** — $5K-$15K/year
- **PolicyNote (FiscalNote)** — $10K-$30K/year
- **MultiState** — $5K-$20K/year

## State-by-State Quick Reference (as of May 2026)

### Critical (SRS 80+)
| State | QSBS Conformity | QOF Conformity | SRS |
|-------|----------------|----------------|-----|
| California | Non-Conforming (13.3%) | Non-Conforming (immediate tax) | 83 |

### High (SRS 60-79)
| State | QSBS Conformity | QOF Conformity | SRS |
|-------|----------------|----------------|-----|
| New York | Active Decoupling (proposed, retroactive) | Partially Conforming | 65 |

### Orange (SRS 41-59)
| State | QSBS Conformity | QOF Conformity | SRS |
|-------|----------------|----------------|-----|
| Connecticut | Non-Conforming | Non-Conforming | 58 |
| Illinois | Non-Conforming | Non-Conforming | 58 |
| Oregon | Active Decoupling (enacted) | Conforming | 55 |
| Maine | Active Decoupling (passed) | Conforming | 50 |
| Maryland | Non-Conforming | Conforming | 45 |
| Hawaii | Conditional (50% cap) | Non-Conforming | 45 |
| Pennsylvania | Non-Conforming (3.07%) | Conforming | 42 |

### Amber (SRS 21-40)
| State | QSBS Conformity | QOF Conformity | SRS |
|-------|----------------|----------------|-----|
| Massachusetts | Conditional (3% tax) | Conforming | 30 |
| North Carolina | Conditional | Conforming | 30 |

### Green (SRS 0-20)
| State | Notes | SRS |
|-------|-------|-----|
| Texas | No state income tax | 5 |
| Florida | No state income tax | 5 |
| Nevada | No state income tax | 5 |
| Wyoming | No state income tax | 5 |
| Tennessee | No state income tax (on wages) | 12 |
| Washington | No state income tax (but enacted LDT) | 20 |
| Colorado | Conforming (with QOF bonus) | 22 |
| New Jersey | Conforms to Section 1202 | 17 |
| Virginia | Conforming | 20 |

## Compliance Considerations

### Reg BI (Regulation Best Interest)
State legislative risk is a **material fact** for deferral strategy recommendations:
- Directly affects after-tax return
- Can change risk/return profile significantly
- May require client action (domicile change, strategy modification)
- Auto-generate regulatory-compliant disclosures

### FINRA Rule 2111
State legislative risk is part of suitability analysis:
- Affects after-tax return (key suitability factor)
- Legislative risk is dynamic (changes over time)
- Must maintain audit trail of assessments at time of each recommendation

### IRS Position on State Tax Advice
Financial advisors providing state tax advice without state license may be engaging in unauthorized practice of law. Include disclaimers:
- "State tax analysis is for informational purposes only and does not constitute state tax advice."
- "Clients should consult a licensed tax professional in their state of domicile."
- "State legislative risk scores are estimates and may not reflect all state-specific nuances."

## Edge Cases

### Retroactive Legislation
- NY proposed decoupling is retroactive to Jan 1, 2025
- System must flag within 24 hours of enactment
- Generate client notification + safe harbor analysis

### Multi-State Domicile
- Track client time allocation by state (183-day rule, principal dwelling)
- Calculate weighted state risk score based on days in each state
- Flag for advisor review

### State Recapture Provisions
- Some states tax gain if client leaves conforming state within N years
- Build recapture risk model: if client leaves within N years, recapture applies
- Recommend minimum time-in-conforming-state period (typically 5-7 years)

### State Sourcing of Business Income
- QSBS corporation incorporated in one state but operating in another
- Some states source based on operations location, not incorporation
- Cross-reference with Section 1202 "domestic corporation" requirements

## Implementation Priority

1. **Phase 1 (MVP):** State conformity database + LegiScan API + basic SRS + advisor dashboard
2. **Phase 2:** Revenue need scoring + political alignment + combined risk calculation
3. **Phase 3:** State domicile optimization engine + retroactive legislation detection
4. **Phase 4:** Multi-state domicile analysis + state sourcing rules + insurance tax monitoring

## Competitive Landscape

Zero wealth management platforms integrate state legislative risk into strategy analysis:
- eMoney, RightCapital, MoneyGuidePro, Orion: basic 50-state tax calculations, no legislative tracking
- Bloomberg Tax, Tax Planner Pro: state tax calculations but no legislative risk modeling
- State Net, PolicyNote: legislative tracking only ($5K-$50K/year, not financial planning tools)

**WealthForge advantage:** Only platform to integrate state legislative risk into deferral strategy analysis — unique value proposition for UHNW clients in non-conforming states.
