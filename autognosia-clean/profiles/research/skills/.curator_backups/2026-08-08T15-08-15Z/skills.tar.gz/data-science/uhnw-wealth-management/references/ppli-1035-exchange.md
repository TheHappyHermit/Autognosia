# PPLI 1035 Exchange Optimization

## When to Exchange (Decision Thresholds)

| Breakeven | Tax Alpha | Action |
|---|---|---|
| < 3 years | > $200K | Strong buy — exchange immediately |
| 3-5 years | $50K-$200K | Conditional — exchange if holding period > breakeven + 2 yrs |
| 5-7 years | $50K-$200K | Wait — recommend surrender charge decay |
| > 7 years | < $50K | Don't exchange — not cost-effective |

## Breakeven Formula

```
Breakeven_Years = (Surrender_Charge + Setup_Cost) / Annual_Fee_Savings
```

Where:
- Surrender_Charge = Cash_Value × Surrecharge_Percentage (from decay schedule)
- Setup_Cost = Carrier setup fee + admin fee
- Annual_Fee_Savings = (Old_Policy_Total_Fee_Rate - New_PPLI_Total_Fee_Rate) × Cash_Value

## Tax Alpha Quantification

```
Tax_Alpha = Gain × (Current_Marginal_Rate - Future_Rate) × e^(-r × T)
```

Cost basis from old policy carries into PPLI (FIFO tracking).

## Six-Carrier Fee Comparison (2026)

| Fee Component | Providence | Arca | Geneva | Axis | RenRe | Pacific Life |
|---|---|---|---|---|---|---|
| M&E Charge | 60-100 bps | 70-120 bps | 80-150 bps | 60-100 bps | 50-90 bps | 70-110 bps |
| Admin Fee | $5K-$15K/yr | $8K-$20K/yr | $10K-$25K/yr | $5K-$12K/yr | $4K-$10K/yr | $6K-$15K/yr |
| SMA Mgmt Fee | 10-30 bps | 15-35 bps | 20-40 bps | 10-30 bps | 10-25 bps | 15-30 bps |
| Setup Fee | $15K-$30K | $20K-$40K | $25K-$50K | $15K-$30K | $10K-$25K | $15K-$35K |
| Min Premium | $1M-$2M | $5M+ | $2M-$5M | $1M-$2M | $1M-$2M | $2M-$5M |

## Underwriting Tiers

| Face Amount | Underwriting | Timeline | Cost |
|---|---|---|---|
| < $1M | No medical / simplified | 1-2 weeks | $0-$2K |
| $1M-$3M | Paramed exam | 2-4 weeks | $500-$1.5K |
| $3M-$5M | Full medical + records | 4-8 weeks | $2K-$5K |
| > $5M | Financial underwriting | 8-12 weeks | $5K-$15K |
| > $10M | + financial + AML | 12-16 weeks | $10K-$25K |

## Health Class COI Impact ($5M face, 55yo male)

| Health Class | COI Age 55 | COI Age 75 | COI Age 85 | Lifetime Savings |
|---|---|---|---|---|
| Standard | $3,500 | $8,200 | $18,500 | Baseline |
| Preferred | $2,800 | $6,500 | $14,800 | -$125K |
| Ultra-Preferred | $2,100 | $4,900 | $11,100 | -$250K |

## IRC §1035 Requirements

1. Ownership must remain unchanged
2. Same insured/annuitant
3. Like-kind: life→life, annuity→annuity
4. No constructive receipt (direct carrier-to-carrier only)
5. Partial exchanges allowed (non-exchanged portion taxed as surrender)

## Red-Team Edge Cases

1. **Constructive receipt**: Pending loans must be settled before exchange
2. **Lapse risk**: New collateral requirements may differ; model CR < 0.50 threshold
3. **Like-kind challenge**: Decreasing death benefit policies may be treated as endowments
4. **Health deterioration**: Recalculate breakeven with worsened health class
5. **Surrender extension**: Some carriers extend charges for 1035 exchanges
6. **Wyden legislative risk**: Proposed elimination for policies >$500K — model accelerate vs. wait
7. **Partial exchange traps**: Non-exchanged portion may have immediate tax consequences

## What Zero Competitors Model

- eMoney: Manual bucket tracking only
- RightCapital: No exchange modeling
- MoneyGuidePro: No exchange modeling
- Orion: Portfolio aggregation only
- Addepar: PPLI tracking but no exchange analysis
