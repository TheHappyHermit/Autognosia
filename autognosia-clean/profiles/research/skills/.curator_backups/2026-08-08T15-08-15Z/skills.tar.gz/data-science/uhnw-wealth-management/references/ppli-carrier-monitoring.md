# PPLI Carrier Health Monitoring

Domain knowledge for monitoring PPLI carrier financial health via US GAAP (DAC) and IFRS 17 (CSM) metrics. Covers Bermuda SAC-level CSM monitoring, acceleration factor calculations, and carrier risk aggregation.

## CSM Floor Proximity (SAC-Level)

### Acceleration Factor (AF)

```
AF = days_to_floor_normal / days_to_floor_stressed
```

Where:
- `days_to_floor_normal` = projected days until CSM reaches 5% floor under normal return assumption
- `days_to_floor_stressed` = projected days until CSM reaches 5% floor under stressed return assumption
- CSM floor threshold = 5% of current CSM value

### DTF Calculation (Exponential Decay Model)

```
CSM(t + Δt) = CSM(t) × exp(r × Δt) - Premium_Inflows × Δt

Days to floor (when r ≠ 0):
DTF = -ln(CSM_floor / (Premium × (1 - exp(-r)))) / r

Days to floor (when r = 0):
DTF = CSM_floor / Premium
```

### AF Asymmetry (Key Insight)

| Normal Return | Stressed Return | DTF Normal | DTF Stressed | Acceleration Factor |
|---------------|-----------------|------------|--------------|-------------------|
| 6.0%          | -4.0%           | 730 days   | 183 days     | 4.0x              |
| 6.0%          | -2.0%           | 730 days   | 365 days     | 2.0x              |
| 6.0%          | 0.0%            | 730 days   | 730 days     | 1.0x              |
| 6.0%          | 2.0%            | 730 days   | 1,460 days   | 0.5x              |
| 6.0%          | 4.0%            | 730 days   | 2,920 days   | 0.25x             |

**Critical**: A -4% shock produces 4x acceleration while +4% gain produces only 0.25x deceleration. The asymmetry is inherent to exponential decay and is the key insight linear models miss.

### AF Classification Thresholds

| AF Range      | Classification | Action                                    |
|---------------|----------------|-------------------------------------------|
| AF < 1.2      | GREEN          | No action                                 |
| 1.2 ≤ AF < 1.5| YELLOW        | Monitor closely                           |
| 1.5 ≤ AF < 2.0| ORANGE        | Review carrier allocation                 |
| AF ≥ 2.0      | RED            | Consider policy restructuring             |

### VFA vs General Model SAC Classification

VFA SACs have market-sensitive CSM (releases with fund returns) — require tighter AF thresholds and daily updates. General Model SACs have predictable CSM release patterns — allow weekly updates and wider thresholds. Must classify each SAC before applying thresholds.

## Carrier Risk Score Aggregation

```
CSM Health Component (0-50): 50 × (1 - weighted_avg_AF / 4.0)
DAC Health Component (0-50): From DAC monitoring research
Composite Score (0-100): CSM_component + DAC_component

Rating:
  0-30: GREEN  |  30-60: YELLOW  |  60-80: ORANGE  |  80-100: RED
```

Weighted average AF uses CSM size as weight across all SACs within a carrier.

## Data Confidence Scoring

```
confidence = 0.3 × data_recency + 0.3 × data_completeness + 0.2 × source_quality + 0.2 × estimation_method
```

- `data_recency`: 1.0 (<30 days), 0.5 (<90 days), 0.2 (<180 days), 0.0 (>180 days)
- `data_completeness`: 1.0 (all inputs), 0.7 (partial), 0.3 (estimated)
- `source_quality`: 1.0 (audited report), 0.7 (regulatory filing), 0.4 (industry estimate)
- `estimation_method`: 1.0 (direct measurement), 0.6 (peer-based), 0.3 (model-based)

## Bermuda PPLI Carrier Data Availability

Most Bermuda PPLI carriers do not disclose SAC-level CSM in public filings. Data must be combined from:
- BMA (Bermuda Monetary Authority) filings
- SEC EDGAR (10-K/10-Q) for carriers with US operations
- Carrier investor reports
- Peer-based estimation (with confidence penalty)

## DAC Monitoring Integration

SAC-level AF alerts should trigger DAC data review for the same carrier. Dual deterioration (high AF + declining DAC) should significantly elevate carrier risk score.

## Key Research Entries

- `RESEARCH_uhnw-01d-1a-1-2c-7e-4b-1a-5b-2a-1a` — Acceleration Factor Dashboard (run 333)
- `RESEARCH_uhnw-01d-1a-1-2c-7e-4b-1a-5b-2a-1` — Exponential Decay Floor Proximity Modeling (run 332)
- `RESEARCH_uhnw-01d-1a-1-2c-7e-4b-1a-5b-2a` — Per-SAC CSM Floor Proximity Alerts (run 331)
- `RESEARCH_uhnw-01d-1a-1-2c-7e-4b-1a-5b` — Bermuda IFRS 17 CSM Monitoring Module (run 330)

## Sources

1. IFRS 17 Insurance Contracts Standard (IASB, 2017) — CSM definition, VFA, coverage unit methodology
2. Fitch Ratings: "IFRS 17 Contractual Service Margin: A Major Step-Up in Insurance Accounting" (Feb 2025) — CSM as carrier health indicator
3. EIOPA: "Report on the implementation of IFRS 17" — CSM rollforward requirements
4. British Actuarial Journal: "The IFRS 17 Contractual Service Margin: A Life Insurance Perspective"
5. Bermuda Segregated Accounts Companies Act 2000 — Legal basis for SAC segregation
6. SOA: "Primer on IFRS 17" — CSM rollforward mechanics, loss component treatment
7. PPLI Solutions: "The Liquidation Trap" — PPLI carrier risk analysis
