# OpenClaw "Unknown Model" Fix - Session Reference

## Problem
Gateway logs showed two missing provider configuration for both Google and OpenRouter:
```text
FailoverError: Unknown model: google/gemini-3-flash-preview.
Found agents.defaults.models["google/gemini-3-flash-preview"],
but no matching models.providers["google"].models[] entry.

FailoverError: Unknown model: openrouter/nvidia/nemotron-3-ultra-550b-a55b:free.
Found agents.defaults.models["openrouter/nvidia/nemotron-3-ultra-550b-a55b:free"],
but no matching models.providers["openrouter"].models[] entry.
```

## Root Cause
The `openclaw.json` config referenced models in `agents.defaults.models` but `models.providers` was missing both providers:

**Google models referenced but no google provider:**
```json
"models": {
  "google/gemini-3.1-pro-preview": {},
  "google/gemini-3-flash-preview": {}
}
```

**OpenRouter model referenced but no openrouter provider:**
```json
"models": {
  "openrouter/nvidia/nemotron-3-ultra-550b-a55b:free": {}
}
```

`models.providers` only had `zai` - **neither `google` nor `openrouter` provider existed**.

## Fix Applied
Added both missing providers under `models.providers`:

### 1. Google Provider
```json
"google": {
  "baseUrl": "https://generativelanguage.googleapis.com/v1beta",
  "api": "google-generative-ai",
  "models": [
    {
      "id": "gemini-3.1-pro-preview",
      "name": "Gemini 3.1 Pro Preview",
      "reasoning": false,
      "input": ["text", "image"],
      "cost": {"input": 3.5, "output": 10.5, "cacheRead": 0.875, "cacheWrite": 0},
      "contextWindow": 2097152,
      "maxTokens": 8192
    },
    {
      "id": "gemini-3-flash-preview",
      "name": "Gemini 3 Flash Preview",
      "reasoning": false,
      "input": ["text", "image"],
      "cost": {"input": 0.075, "output": 0.3, "cacheRead": 0.01875, "cacheWrite": 0},
      "contextWindow": 1048576,
      "maxTokens": 8192
    }
  ]
}
```

### 2. OpenRouter Provider
```json
"openrouter": {
  "baseUrl": "https://openrouter.ai/api/v1",
  "api": "openai-completions",
  "models": [
    {
      "id": "nvidia/nemotron-3-ultra-550b-a55b:free",
      "name": "Nemotron 3 Ultra (Free)",
      "reasoning": false,
      "input": ["text"],
      "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0},
      "contextWindow": 128000,
      "maxTokens": 4096
    }
  ]
}
```

## Verification
All checks passed:
- Gateway health: `{"ok":true,"status":"live"}`
- Logs show: `agent model: openrouter/nvidia/nemotron-3-ultra-550b-a55555b:free`
- No "Unknown model" errors in logs
- Fallback chain intact: **OpenRouter (primary) → Google → Z.ai**

## Key Learnings
- **Always check `models.providers` matches `agents.defaults.models`** - every model ID prefix (before `/`) must have a corresponding provider entry
- OpenRouter uses `openai-completions` API type, Google uses `google-generative-ai` (NOT `google-generative-language`)
- Provider `models[]` entries must have `id` matching the model ID suffix (after the `/` prefix)
- Fallback chain only works if ALL providers in the chain are properly configured in `models.providers`

## Common Pitfalls
- Using wrong `api` type (must be exactly `google-generative-ai`, not `google-generative-language`)
- Forgetting to register models with matching `id` values
- Missing `models.providers` entry entirely for a referenced provider
- Model IDs in agents config don't match provider model IDs exactly

## Files Changed
- `/home/josh434/.openclaw/openclaw.json` - Added google provider to models.providers