# OpenRouter Free Model Recommendations for OpenClaw

## Current Best Free Models (as of July 2026)

Based on community testing and benchmarks, these are the **recommended free models** on OpenRouter for OpenClaw agentic workflows, ranked by reliability and capability:

### 1. openai/gpt-oss-120b:free
- **Provider:** OpenAI (via OpenRouter)
- **Best for:** Reliable tool use & reasoning, general agent tasks
- **Context:** 128K tokens
- **Notes:** Strong tool calling, good for daily assistant work

### 2. qwen/qwen3-coder:free
- **Provider:** Qwen
- **Best for:** Complex agent workflows, coding tasks
- **Context:** 128K+ tokens
- **Notes:** Excellent for agentic coding, better than DeepSeek for some workflows

### 3. google/gemma-4-31b-it:free
- **Provider:** Google
- **Best for:** Fast, efficient tasks, news summaries
- **Context:** 128K+ tokens
- **Notes:** Very fast, good for classification/extraction

### 4. z-ai/glm-4.5-air:free
- **Provider:** Z.ai
- **Best for:** Agent-centric tasks specifically
- **Context:** 200K+ tokens
- **Notes:** Built for agent workflows, but Z.ai free tier has billing issues

### 5. deepseek/deepseek-v3.2:free
- **Provider:** DeepSeek
- **Best for:** General reasoning, coding fallback
- **Context:** 131K tokens
- **Notes:** More reliable free tier than Nemotron, 12 providers on OpenRouter for redundancy

### 6. meta-llama/llama-3.3-70b-instruct:free
- **Provider:** Meta (via various providers on OpenRouter)
- **Best for:** General chat, drafting, "Gold Standard" free model
- **Context:** 128K tokens
- **Notes:** Check if :free variant is active (rotates frequently)

## Models to AVOID on Free Tier

| Model | Reason |
|-------|--------|
| `nvidia/nemotron-3-ultra-550b-a55b:free` | **32 concurrent worker limit** - constant "Worker local total request limit reached (33/32)" errors |
| `nvidia/nemotron-3-super-120b-a12b:free` | Same worker limit issue as Ultra |
| `z-ai/glm-5.1:free` | Z.ai free tier has insufficient balance/billing errors |

## OpenRouter Free Tier Limits

| Tier | RPM | RPD | Notes |
|------|-----|-----|-------|
| Free (no credit card) | 20 | 50/day | Very limited |
| **$10+ lifetime credits** | 20 | **1,000/day** | **Best value** - one-time deposit unlocks 20x daily quota |

**The $10 deposit is highly recommended** - it's a one-time purchase, not a subscription, and removes the 50/day cap.

## Nemotron 3 Ultra vs DeepSeek V3.2 Comparison

| Metric | Nemotron 3 Ultra | DeepSeek V3.2 |
|--------|------------------|---------------|
| BenchLM Overall | **66** (#21) | 56 (unranked) |
| Coding | **74.2** | 60.9 |
| Context Window | **1M** | 131K |
| Free Tier Reliability | **Poor** (32 worker limit) | **Good** (12 providers) |
| Paid Pricing | $0.085/$0.40 per 1M | $0.2288/$0.3432 per 1M |
| Latency (p50) | 1.85s | 1.26s |
| Throughput | 42 tok/s | 20 tok/s |

**Bottom line:** Nemotron is better for coding/agentic work **if paid**, but DeepSeek V3.2 is **far more reliable on free tier**.

## Recommended Fallback Chain for OpenClaw

```json
{
  "agents": {
    "defaults": {
      "model": {
        "primary": "openrouter/auto",
        "fallbacks": [
          "deepseek/deepseek-v3.2:free",
          "qwen/qwen3-coder:free",
          "openai/gpt-oss-120b:free",
          "google/gemma-4-31b-it:free"
        ]
      }
    }
  }
}
```

**Why `openrouter/auto` as primary?** It routes to whatever free model has capacity at request time, avoiding single-model rate limits.

## Provider Configuration Requirements

Every model in the fallback chain MUST have a corresponding entry in `models.providers`:

```json
"models": {
  "providers": {
    "openrouter": {
      "baseUrl": "https://openrouter.ai/api/v1",
      "api": "openai-completions",
      "models": [
        {"id": "auto", "name": "OpenRouter Auto", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 128000, "maxTokens": 4096}
      ]
    },
    "deepseek": {
      "baseUrl": "https://api.deepseek.com/v1",
      "api": "openai-completions",
      "models": [
        {"id": "deepseek-v3.2", "name": "DeepSeek V3.2", "reasoning": false, "input": ["text"], "cost": {"input": 0.2288, "output": 0.3432, "cacheRead": 0.02288, "cacheWrite": 0}, "contextWindow": 131072, "maxTokens": 8192}
      ]
    },
    "qwen": {
      "baseUrl": "https://api.qwen.ai/v1",
      "api": "openai-completions",
      "models": [
        {"id": "qwen3-coder", "name": "Qwen3 Coder", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 131072, "maxTokens": 8192}
      ]
    },
    "google": {
      "baseUrl": "https://generativelanguage.googleapis.com/v1beta",
      "api": "google-generative-ai",
      "models": [
        {"id": "gemma-4-31b-it", "name": "Gemma 4 31B IT", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 131072, "maxTokens": 8192}
      ]
    }
  }
}
```

## Key Learnings from This Session

1. **Always verify `models.providers` matches `agents.defaults.models`** - every model prefix needs a provider
2. **OpenRouter uses `openai-completions` API type**, Google uses `google-generative-ai` (NOT `google-generative-language`)
3. **Nemotron free tier has a hard 32-worker limit** from NVIDIA NIM backend - not fixable via OpenClaw config
4. **$10 OpenRouter deposit unlocks 1,000 req/day** - best ROI for free-tier users
5. **DeepSeek V3.2 free > Nemotron free** for reliability; Nemotron paid > DeepSeek paid for coding
6. **Use `openrouter/auto` as primary** to let OpenRouter handle routing to available free models
7. **Provider `models[]` must have matching `id` values** - the suffix after the provider prefix

## Updated OpenClaw Configuration Pattern

```json
{
  "agents": {
    "defaults": {
      "models": {
        "openrouter/auto": {"alias": "OpenRouter"},
        "deepseek/deepseek-v3.2:free": {},
        "qwen/qwen3-coder:free": {},
        "openai/gpt-oss-120b:free": {},
        "google/gemma-4-31b-it:free": {}
      },
      "model": {
        "primary": "openrouter/auto",
        "fallbacks": [
          "deepseek/deepseek-v3.2:free",
          "qwen/qwen3-coder:free",
          "openai/gpt-oss-120b:free",
          "google/gemma-4-31b-it:free"
        ]
      }
    },
    "list": [
      {"id": "main", "model": {"primary": "openrouter/auto", "fallbacks": ["deepseek/deepseek-v3.2:free", "qwen/qwen3-coder:free"]}}
    ]
  },
  "models": {
    "mode": "merge",
    "providers": {
      "openrouter": {"baseUrl": "https://openrouter.ai/api/v1", "api": "openai-completions", "models": [{"id": "auto", "name": "OpenRouter Auto", ...}]},
      "deepseek": {"baseUrl": "https://api.deepseek.com/v1", "api": "openai-completions", "models": [{"id": "deepseek-v3.2", ...}]},
      "qwen": {"baseUrl": "https://api.qwen.ai/v1", "api": "openai-completions", "models": [{"id": "qwen3-coder", ...}]},
      "google": {"baseUrl": "https://generativelanguage.googleapis.com/v1beta", "api": "google-generative-ai", "models": [{"id": "gemma-4-31b-it", ...}]}
    }
  }
}
```

## Quick Diagnostic Commands

```bash
# Check which models are referenced but missing providers
grep -o '\"[a-z-]*/[^\"]*\"' ~/.openclaw/openclaw.json | sort -u

# List configured providers
jq '.models.providers | keys' ~/.openclaw/openclaw.json

# Check specific model in providers
jq '.models.providers.openrouter.models[] | .id' ~/.openclaw/openclaw.json
```

## Related Files
- `references/unknown-model-fix.md` - Session reference for the "Unknown model" fix
- `references/valid-api-types.md` - Valid `api` type values for provider config