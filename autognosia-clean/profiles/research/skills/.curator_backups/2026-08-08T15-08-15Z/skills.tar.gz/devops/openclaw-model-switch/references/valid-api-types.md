# OpenClaw Valid Model Provider API Types

Reference for the `api` field in `models.providers.<provider>` configuration.

## Valid API Types (as of OpenClaw 2026.6.11)

| API Type | Use Case | Example Provider |
|----------|----------|------------------|
| `openai-completions` | OpenAI-compatible completions endpoint | OpenRouter, local vLLM, etc. |
| `openai-responses` | OpenAI Responses API | OpenAI, compatible proxies |
| `openai-chatgpt-responses` | ChatGPT-specific Responses API | OpenAI |
| `anthropic-messages` | Anthropic Messages API | Anthropic, compatible proxies |
| `google-generative-ai` | Google Generative Language API (Gemini) | Google AI Studio, Vertex AI |
| `google-vertex` | Google Vertex AI | Google Cloud Vertex AI |
| `github-copilot` | GitHub Copilot API | GitHub |
| `bedrock-converse-stream` | AWS Bedrock Converse Streaming | AWS Bedrock |
| `ollama` | Local Ollama server | Ollama |
| `azure-openai-responses` | Azure OpenAI Responses API | Azure OpenAI |

## Google Provider Example

```json
"google": {
  "baseUrl": "https://generativelanguage.googleapis.com/v1beta",
  "api": "google-generative-ai",
  "models": [
    {
      "id": "gemini-3.1-pro-preview",
      "name": "Gemini 3.1 Pro Preview",
      "reasoning": false,
      "input": ["text", "image"],
      "cost": {"input": 3.5, "output": 10.5, "cacheRead": 0.875, "cacheWrite": 0},
      "contextWindow": 2097152,
      "maxTokens": 8192
    },
    {
      "id": "gemini-3-flash-preview",
      "name": "Gemini 3 Flash Preview",
      "reasoning": false,
      "input": ["text", "image"],
      "cost": {"input": 0.075, "output": 0.3, "cacheRead": 0.01875, "cacheWrite": 0},
      "contextWindow": 1048576,
      "maxTokens": 8192
    }
  ]
}
```

## Key Rules

1. Every model ID referenced in `agents.defaults.models` or `agents.list[].model` MUST appear in exactly one `models.providers.<provider>.models[]` entry with matching `id`
2. The `api` field MUST be one of the valid types above (case-sensitive)
3. `baseUrl` should point to the provider's API endpoint (no trailing slash needed)
4. Model `id` values are provider-specific and must match what the API expects