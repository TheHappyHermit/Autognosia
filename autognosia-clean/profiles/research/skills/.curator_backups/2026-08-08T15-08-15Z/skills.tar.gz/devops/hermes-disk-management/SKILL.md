---
name: hermes-disk-management
description: Periodic disk maintenance for Hermes Agent — state snapshot cleanup, cron output pruning, and general disk audit.
---

# Hermes Disk Management

Periodic maintenance of disk usage across the Hermes workspace.

## State Snapshot Cleanup

State snapshots in `~/.hermes/state-snapshots/` are pre-update backups that can grow to **5 GB+ each**. They contain copies of `state.db`, `config.yaml`, `auth.json`, cron jobs, and channel directory — useful for rollback but not for research or workspace data.

### When to clean
- Total snapshot directory exceeds ~15 GB
- User reports disk pressure
- Routine maintenance check

### Procedure
1. Run `du -sh ~/.hermes/state-snapshots/*/ 2>/dev/null | sort -rh` to see sizes
2. Keep the **2 most recent** snapshots (for rollback safety)
3. Delete the rest: `rm -rf ~/.hermes/state-snapshots/<oldest-dirs>/`
4. Verify remaining space with `du -sh ~/.hermes/state-snapshots/*/ 2>/dev/null | sort -rh`

**Never delete all snapshots** — always keep at least 2 for rollback.

## Cron Output Cleanup

Cron job outputs live in `~/.hermes/cron/output/<job_id>/` as timestamped `.md` files. These accumulate over time.

### Procedure
1. `du -sh ~/.hermes/cron/output/<job_id>/` to check size
2. List files: `ls -la ~/.hermes/cron/output/<job_id>/`
3. Delete old files selectively or the entire directory if the user wants a clean slate
4. Note: cron jobs will regenerate outputs on next run

### Key job IDs
- `8caabef37c22` — WealthForge Deep Research (runs every 10 min)
- `eebf16fd600a` — Morning Newsletter (6 AM)
- `2fdcb131de85` — Evening Newsletter (9 PM)

## NAS Drive (/mnt/nas/)

**Mounted at `/mnt/nas/` but owned by root.** The josh434 user can read but NOT write. Any copy/mkdir operations will fail with permission denied.

- Contents: `/mnt/nas/backups/VMs/` (empty, VM backup target)
- To write: requires `sudo` (password needed — can't be automated from agent)
- **Workaround**: Use alternative writable storage (local backup dir, cloud, etc.) or ask user to run the copy command manually

## General Disk Audit

When user reports disk pressure, check these in order:
1. `~/.hermes/state-snapshots/` — pre-update backups (can be 5 GB+ each)
2. `~/.hermes/cron/output/` — cron job outputs (accumulate over time)
3. `~/.hermes/memory_enhancement/` — SQLite memory database
4. `~/Documents/Hermes-Vault/` — Obsidian vault
5. `~/.hermes/media_cache/` — cached media files
6. `~/.hermes/audio_cache/` — TTS audio files
