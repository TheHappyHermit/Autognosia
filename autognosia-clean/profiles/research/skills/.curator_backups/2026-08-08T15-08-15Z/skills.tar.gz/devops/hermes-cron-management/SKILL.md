---
name: hermes-cron-management
description: Manage Hermes cron jobs — update model/provider via CLI.
version: 1.0.0
author: Hermes Agent
license: MIT
---

# Hermes Cron Job Management

Hermes cron jobs run scheduled tasks (newsletter generation, research, maintenance) with configurable models, providers, and delivery targets.

## Key Workflows

### Update Model/Provider for Existing Cron Job

**Use `hermes cron edit` CLI command** — the `cronjob` tool's `update` action requires the full prompt to persist changes; you cannot update only `model`/`provider` in isolation.

```bash
# Correct approach
hermes cron edit <job_id> --model nvidia/nemotron-3-ultra-550b-a55b:free --provider openrouter

# Incorrect - fails with "No updates provided"
cronjob action='update' job_id='...' model='...' provider='...'
```

### Create New Cron Job

```bash
hermes cron create "0 6 * * *" --prompt "Run newsletter script" --model "anthropic/claude-sonnet-4" --provider anthropic --deliver telegram
```

### List and Inspect Jobs

```bash
hermes cron list           # enabled jobs
hermes cron list --all     # include disabled/paused
cronjob action='list'      # tool equivalent (returns full JSON)
```

## Common Pitfalls

| Pitfall | Symptom | Fix |
|---------|---------|-----|
| Partial update via cronjob tool | "No updates provided" error | Use `hermes cron edit` or provide full `prompt` + `schedule` + `model` + `provider` |
| Model change not persisting | `cronjob list` still shows old model | Verify with `hermes cron list`; CLI writes take effect immediately |
| Skills not loading in cron run | Job runs but skill tools unavailable | Attach skills at create: `hermes cron create ... --skills freshrss-integration` |
| Reasoning model stalls in cron | Job runs but only produces reasoning, no final answer | Add explicit output constraint to prompt, reduce frequency, or switch to non-reasoning model (see `wealthforge-research-workflow` references/reasoning-model-stalling.md) |

## Delivery Targets

- `telegram` — deliver to configured Telegram chat
- `local` — save output only, no delivery
- `origin` — deliver to originating chat/topic
- `all` — fan out to all connected channels

## References

- `references/cron-update-workaround.md` — detailed transcript of the partial-update failure and CLI workaround