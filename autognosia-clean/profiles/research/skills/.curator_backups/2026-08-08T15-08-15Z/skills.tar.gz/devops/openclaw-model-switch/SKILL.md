---
name: openclaw-model-switch
description: Procedure for changing primary model for all OpenClaw agents and verifying operation
category: devops
---

# OpenClaw Model Switch & Config Repair Procedure

## Trigger Conditions
- Need to change primary model for all OpenClaw agents
- OpenClaw not responding properly after configuration changes
- Preparing OpenClaw for new model testing/deployment
- Gateway fails with "Unknown model" or "FailoverError: Unknown model" errors
- Provider configuration missing from models.providers section

## Prerequisites
- OpenClaw installed and running
- Access to ~/.openclaw/openclaw.json
- Basic shell tools (sed, pkill, nohup, curl)
- Target model available (e.g., openrouter/nvidia/nemotron-3-super-120b-a12b:free)

## Steps

### 1. Backup Configuration
```bash
cp ~/.openclaw/openclaw.json ~/.openclaw/openclaw.json.backup
```

### 1b. Diagnose Missing Provider Configuration (NEW)
If gateway logs show "FailoverError: Unknown model" but model is listed in agents.defaults.models:
```bash
# Check which models are referenced but missing from providers
grep -o '"google/[^"]*"' ~/.openclaw/openclaw.json | sort -u
grep -o '"openrouter/[^"]*"' ~/.openclaw/openclaw.json | sort -u
# Compare with providers section
jq '.models.providers | keys' ~/.openclaw/openclaw.json
```

**Fix: Add missing provider entry**
Add the missing provider to `models.providers` with correct `api` type and model registry. The `api` type MUST match one of the valid OpenClaw provider API types (see below).

**Common missing providers:**

**Google Generative AI:**
```json
"google": {
  "baseUrl": "https://generativelanguage.googleapis.com/v1beta",
  "api": "google-generative-ai",
  "models": [
    {"id": "gemini-3.1-pro-preview", "name": "Gemini 3.1 Pro Preview", "reasoning": false, "input": ["text", "image"], "cost": {"input": 3.5, "output": 10.5, "cacheRead": 0.875, "cacheWrite": 0}, "contextWindow": 2097152, "maxTokens": 8192},
    {"id": "gemini-3-flash-preview", "name": "Gemini 3 Flash Preview", "reasoning": false, "input": ["text", "image"], "cost": {"input": 0.075, "output": 0.3, "cacheRead": 0.01875, "cacheWrite": 0}, "contextWindow": 1048576, "maxTokens": 8192}
  ]
}
```

**OpenRouter (OpenAI-compatible):**
```json
"openrouter": {
  "baseUrl": "https://openrouter.ai/api/v1",
  "api": "openai-completions",
  "models": [
    {"id": "nvidia/nemotron-3-ultra-550b-a55b:free", "name": "Nemotron 3 Ultra (Free)", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 128000, "maxTokens": 4096},
    {"id": "z-ai/glm-4.5-air:free", "name": "GLM 4.5 Air (Free)", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 200000, "maxTokens": 128000},
    {"id": "openai/gpt-oss-120b:free", "name": "GPT-OSS 120B (Free)", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 131072, "maxTokens": 8192},
    {"id": "qwen/qwen3-coder:free", "name": "Qwen3 Coder (Free)", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 131072, "maxTokens": 8192},
    {"id": "google/gemma-4-31b-it:free", "name": "Gemma 4 31B (Free)", "reasoning": false, "input": ["text"], "cost": {"input": 0, "output": 0, "cacheRead": 0, "cacheWrite": 0}, "contextWindow": 131072, "maxTokens": 8192}
  ]
}
```

**Valid `api` types:** `google-generative-ai`, `google-vertex`, `openai-completions`, `openai-responses`, `anthropic-messages`, `bedrock-converse-stream`, `ollama`, `github-copilot`, `azure-openai-responses`

### 1c. OpenRouter Free Tier Worker Limits (UPDATED)
**Symptom:** `ResourceExhausted: Worker local total request limit reached (33/32)` from NVIDIA Nemotron models.

**Root cause:** NVIDIA's free-tier NIM backend enforces a **32 concurrent worker limit** per account. This is an OpenRouter/NVIDIA infrastructure limit, NOT an OpenClaw config issue. Affects ALL Nemotron models on free tier.

**Workarounds (ranked by OpenClaw Unboxed + community testing):**
1. **Primary: `z-ai/glm-4.5-air:free`** — #1 ranked by OpenClaw Unboxed, specifically built for agent-centric tasks, 200K context, no worker limit issues
2. **Fallback: `openai/gpt-oss-120b:free`** — Reliable tool use & reasoning, 131K context, OpenAI-hosted (different infrastructure)
3. **Fallback: `qwen/qwen3-coder:free`** — Excellent for complex agent workflows, code-heavy tasks
4. **Fallback: `google/gemma-4-31b-it:free`** — Fast, efficient, good for quick tasks
5. **`openrouter/auto`** — Routes to any available free model (unpredictable, but works)
6. Add $5-10 credits to OpenRouter to remove free-tier limits entirely

**AVOID on free tier:** All Nemotron models (`nvidia/nemotron-3-*:free`) — hard 32-worker limit makes them unreliable for agent workloads.

**Note:** OpenClaw's `auth.cooldowns` only controls retry backoff AFTER provider returns 429 — cannot increase provider worker limits.

### 2. Update All Agent Models
Replace primary_model for all agents and defaults:
```bash
# Using sed (adjust model name as needed)
NEW_MODEL="openrouter/nvidia/nemotron-3-super-120b-a12b:free"

sed -i "s/\"primary_model\": \".*\"/\"primary_model\": \"$NEW_MODEL\"/g" ~/.openclaw/openclaw.json
```

Verify change:
```bash
grep -A2 -B2 "primary_model" ~/.openclaw/openclaw.json | head -20
```

### 3. Restart OpenClaw Gateway
```bash
# Stop existing instance
pkill -f openclaw

# Start fresh instance
nohup python3 -m openclaw.gateway.run > /tmp/openclaw.log 2>&1 &
echo $! > /tmp/openclaw.pid
```

### 4. Verify Health Endpoint
```bash
# Wait a moment for startup
sleep 3

# Check health
curl -s http://127.0.0.1:8080/health
# Expected: {"ok":true,"status":"live"}
```

### 5. Monitor Logs
```bash
tail -f /tmp/openclaw.log
```
Look for:
- Agent initialization messages
- WebSocket connection established
- No authentication or model loading errors

### 6. Test Connectivity
- Web UI: http://127.0.0.1:8080 should load
- Telegram bot: /start should respond
- Check session store: http://127.0.0.1:8080/sessions

## Agents Updated
- main
- coder  
- flowbot
- system-maintainer
- researcher
- officeworker
- homey
- news
- oracle
- defaults (all)

## Verification Checklist
[ ] Backup created
[ ] All primary_model entries updated
[ ] Gateway restarted successfully
[ ] Health endpoint returns live status
[ ] No error logs in openclaw.log
[ ] Web UI accessible
[ ] Telegram bot responsive

## Troubleshooting
- If health check fails: check /tmp/openclaw.log for startup errors
- If agents don't load: verify JSON syntax after sed changes
- If model unavailable: check OpenRouter API key and model availability
- For persistent issues: restore backup and retry with different approach

## Related Skills
- application-cleanup-verification (for troubleshooting OpenClaw issues)
- honcho-deployment (if memory system needs attention)

## Related References
- `references/free-model-recommendations.md` — Current best free models on OpenRouter, Nemotron free-tier limits, recommended fallback chains
- `references/unknown-model-fix.md` — Session reference for the "Unknown model" fix
- `references/valid-api-types.md` — Valid `api` type values for provider config